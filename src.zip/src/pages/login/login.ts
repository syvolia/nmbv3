import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams , MenuController, LoadingController, ModalController, Platform } from 'ionic-angular';
import { GlobalVarsProvider } from '../../providers/global-vars/global-vars';
import { ApiConnectProvider } from '../../providers/api-connect/api-connect';
import { ConnectivityServiceProvider } from '../../providers/connectivity-service/connectivity-service';

import { Toast } from '@ionic-native/toast';
import { Storage } from '@ionic/storage';
import { Device } from '@ionic-native/device';
import { SocialSharing } from '@ionic-native/social-sharing';

/**
 * Generated class for the LoginPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

declare var cordova:any;
declare var window: any;

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  objectblock:any={};
  accounts:any;
  body:any="";
  data:any;
  header:any;
  token:any;
  isPasswordForm:boolean=false;
  smses:any;
  mobileNo:string="";
  userNumber:string="";
  myOtp:string="";

  constructor(public navCtrl: NavController, public navParams: NavParams, public globalVars: GlobalVarsProvider
    , public loadingController: LoadingController, public modalCtrl: ModalController,
    private toast: Toast, public connectivityService: ConnectivityServiceProvider, public apiConnect: ApiConnectProvider,
    private storage: Storage, private device: Device, private socialSharing: SocialSharing,
    public platform: Platform, public menu: MenuController) {
    this.menu.swipeEnable(false);
   storage.get('xyz').then((val) => {
      if(val){
        this.isPasswordForm=true;
        let uuidmobilemix = val;
        let uuid = this.device.uuid;
        this.mobileNo=globalVars.doAESdecrypt(uuidmobilemix, uuid+"blablahblah");
        globalVars.setUsername(this.mobileNo);
      }
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }
  openPage(page){
    if(page=="LocationtabsPage"){
      this.globalVars.setFromLogin(true);
    }
  	this.navCtrl.push(page);
  }
  submit(objectblock){
    if(objectblock.user==""||objectblock.user==undefined){
      let template="<div>Kindly enter a valid Mobile number</div>";
      let obj={body:this.body, template:template, completed:true, pageTo:''};
      let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
      myModal.present();
    }
    else if(objectblock.pass==""||objectblock.pass==undefined){
      let template="<div>Kindly enter a valid PIN</div>";
      let obj={body:this.body, template:template, completed:true, pageTo:''};
      let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
      myModal.present();
    }
    else if(!(/^\d{10}$/.test(objectblock.user))){
      let template="<div>Kindly enter a valid Mobile number</div>";
      let obj={body:this.body, template:template, completed:true, pageTo:''};
      let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
      myModal.present();
    }
    else if(!(/^\d{4}$/.test(objectblock.pass))){
      let template="<div>Kindly enter a valid PIN</div>";
      let obj={body:this.body, template:template, completed:true, pageTo:''};
      let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
      myModal.present();
    } 
    else{
      let userNumber=objectblock.user;
      this.userNumber="255"+userNumber.substr(userNumber.length-9);

      console.log(this.userNumber);
      if(this.connectivityService.isOnline()){
        this.token=this.globalVars.createToken();
        let hashPass=this.globalVars.getHashPass(objectblock);
        this.globalVars.setUsername(this.userNumber);
        this.body=JSON.stringify({
          esbRequest: {
            f0: "0200",
            f2: this.userNumber,
            f3: "110200",
            ESBUser: "chapchapplus",
            ESBWS: "http://192.168.60.233:7010/ESBWSConnector",
            ESBPassword: "chapchapplus",
            data:{
              37: this.token.field37,
            }        
          },
          mnoSession: {
            id: this.globalVars.getDate("9"),
            msisdn: this.userNumber,
            password:hashPass,
            deviceid: this.device.uuid
          }
          
        });
          
        this.body=this.globalVars.getEncryptedVars(this.body);
        //console.log(this.body);
        
        this.makeRequest();
            
      }
      else{
        this.toast.show("Please connect to the Internet", '8000', 'bottom').subscribe(
          toast => {
         // console.log(toast);
        });
      }
    }

  }
  submitPIN(objectblock){
    //console.log("ddjd");
   if(objectblock.pass==""||objectblock.pass==undefined){
      let template="<div>Kindly enter a valid PIN</div>";
      let obj={body:this.body, template:template, completed:true, pageTo:''};
      let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
      myModal.present();
    }
    else if(!(/^\d{4}$/.test(objectblock.pass))){
      let template="<div>Kindly enter a valid PIN</div>";
      let obj={body:this.body, template:template, completed:true, pageTo:''};
      let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
      myModal.present();
    } 
    else{
      let userNumber=this.mobileNo;
      this.userNumber="255"+userNumber.substr(userNumber.length-9);

      if(this.connectivityService.isOnline()){
        this.token=this.globalVars.createToken();
        objectblock.user=this.userNumber;
        let hashPass=this.globalVars.getHashPass(objectblock);
        this.globalVars.setUsername(this.userNumber);
        this.body=JSON.stringify({
          esbRequest: {
            f0: "0200",
            f2: this.userNumber,
            f3: "110200",
            ESBUser: "chapchapplus",
            ESBWS: "http://192.168.60.233:7010/ESBWSConnector",
            ESBPassword: "chapchapplus",
            data:{
              37: this.token.field37,
            }        
          },
          mnoSession: {
            id: this.globalVars.getDate("9"),
            msisdn: this.userNumber,
            password:hashPass,
            deviceid: this.device.uuid
          }
          
        });
          
        this.body=this.globalVars.getEncryptedVars(this.body);
        //console.log(this.body);
        
        this.makeRequest();
            
      }
      else{
        this.toast.show("Please connect to the Internet", '8000', 'bottom').subscribe(
          toast => {
          //console.log(toast);
        });
      }
    }
  }
  
  makeRequest(){
    if(this.connectivityService.isOnline()){
    let loader = this.loadingController.create({content:'Submitting Request'});
      loader.present();
      let body=this.body;
      let header= this.token;
      //console.log(header.hmac+"________"+header.token);
      this.apiConnect.load(body,header).then(data => {
        
        this.data=data;
        if(this.data.error==""){
          
          let response=this.globalVars.getDecryptedVars(this.data.data);
           console.log(response);
           //console.log(response.LINKEDACCOUNTS);

          if(response.field39 == "00"){
            loader.dismiss();
            let encrypted = this.globalVars.doAESencrypt(this.userNumber, this.device.uuid+"blablahblah");
            this.storage.set('xyz', encrypted);
            this.accounts=[response.ACCOUNTNUMBER];
            this.globalVars.setUsername(response.PHONENUMBER);
            this.globalVars.setCustomerName(response.CUSTOMERNAME);
            this.globalVars.setEmail(response.EMAILADDRESS);
            let currencyTemplate=[{account:response.ACCOUNTNUMBER,currency:"TZS"}];
            if("LINKEDACCOUNTS" in response){
              if(response.LINKEDACCOUNTS!=undefined||response.LINKEDACCOUNTS!=""){
                let linked=this.transform(JSON.parse(response.LINKEDACCOUNTS));
                for(var i=0;i<linked.length;i++){
                   this.accounts.push(linked[i].ACCOUNTNUMBER);
                   currencyTemplate.push({account:linked[i].ACCOUNTNUMBER,currency:linked[i].ACCOUNTCURRENCY})
                }
              }
            }
            if("LINKEDCARDS" in response){
              if(response.LINKEDCARDS!=undefined||response.LINKEDCARDS!=""){
                let linked=this.transform(JSON.parse(response.LINKEDCARDS));
                for(var i=0;i<linked.length;i++){
                   this.globalVars.linkedCards.push({CARDNUMBERMASKED:linked[i].CARDNUMBERMASKED,CARDNUMBER:linked[i].CARDNUMBER});  
                }
              }
            }

            this.globalVars.setCIF(response.CIF);
            this.globalVars.setAccounts(this.accounts);

            this.globalVars.setCurrencyTemplate(currencyTemplate);
            this.navCtrl.setRoot('MainPage');
          }
          else if(response.field39=="001"){
            loader.dismiss();
            let template="<div>Kindly setup on USSD before proceeding</div>";
            let obj={body:this.body, template:template, completed:true, pageTo:''};
            let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
            myModal.present();
          }
          else if(response.field39=="002"){

            this.myOtp=response.otp;
            if(this.device.platform!="Android"){
              this.platform.ready().then(() => { 
                var permissions = cordova.plugins.permissions;

                permissions.hasPermission(permissions.READ_SMS, checkPermissionCallback, null);

                this.readSMS(response.otp).then(data => {
                  loader.dismiss();
                  let dataResponse=data;
                  if(dataResponse.found){
                    this.updateUUID();
                  }
                  else if(dataResponse.error){
                    let myModal = this.modalCtrl.create('VerifyotpPage');
                    myModal.present();
                    myModal.onDidDismiss(data=>{ 
                      console.log("Data =>"+ data);
                      if(data==this.myOtp){
                        this.updateUUID();
                      }
                      else{
                        let template="<div>Verification code did not match. Kindly try again</div>";
                        let obj={body:this.body, template:template, completed:true, pageTo:''};
                        let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
                        myModal.present();
                      }
                    });
                  }
                  else{
                    let template="<div>Failed to retreive SMS <br> Kindly try again</div>";
                    let obj={body:this.body, template:template, completed:true, pageTo:''};
                    let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
                    myModal.present();
                  }
                   
                });
                function checkPermissionCallback(status) {
                  if(!status.hasPermission) {
                    var errorCallback = function() {
                      alert('READ_SMS permission is not turned on');
                    }

                    permissions.requestPermission(
                    permissions.READ_SMS,
                    function(status) {
                      if(!status.hasPermission) {
                        errorCallback();
                      }
                    },errorCallback);
                  }
                }

              });
            }
            else{
              loader.dismiss();
              let myModal = this.modalCtrl.create('VerifyotpPage');
              myModal.present();
              myModal.onDidDismiss(data=>{ 
                console.log("Data =>"+ data);
                if(data!=this.myOtp){
                  this.updateUUID();
                }
                else{
                  let template="<div>Verification code did not match. Kindly try again</div>";
                  let obj={body:this.body, template:template, completed:true, pageTo:''};
                  let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
                  myModal.present();
                }
              });
            }
          }
          else{
            if("message" in response){
              loader.dismiss();
              let template="<div>Request failed <br>"+response.message+"</div>";
              let obj={body:this.body, template:template, completed:true, pageTo:''};
              let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
              myModal.present();
            }
            else{
              loader.dismiss();
              let template="<div>Request failed <br>"+response.field48+"</div>";
              let obj={body:this.body, template:template, completed:true, pageTo:''};
              let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
              myModal.present();
            }
          }

        }
        else{
          loader.dismiss();
          let template="<div>"+this.data.error+"</div>";
          let obj={body:this.body, template:template, completed:true, pageTo:''};
          let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
          myModal.present();
        }
        
      });   
    }
    else{
      this.toast.show("Please connect to the Internet", '8000', 'bottom').subscribe(
        toast => {
       // console.log(toast);
      });
    }
  }
  transform(value: any, args?: any[]): any[] {
      // create instance vars to store keys and final output
      let keyArr: any[] = Object.keys(value),
          dataArr = [];

      // loop through the object,
      // pushing values to the return array
      keyArr.forEach((key: any) => {
          dataArr.push(value[key]);
      });

      // return the resulting array
      return dataArr;
  }
  readSMS(search): Promise<any> {
 
    return new Promise((resolve) => {
      let startTime = new Date().getTime();
      let filter={box:'inbox', address:"NMB", body:search, maxCount:1000};
      let smsresponse={found:false,error:false};
      var temp = this;
      var interval=setInterval(()=>{
         
        if ((new Date().getTime() - startTime) > 30000) {

          clearInterval(interval);
          smsresponse = {found:false,error:false};
          resolve(smsresponse);
        }
        if(window.SMS) window.SMS.listSMS(filter,data=>{
            temp.smses=data;
            for(var i=0;i<temp.smses.length;i++){
                
              if(temp.smses[i].address == "NMB" && temp.smses[i].body.indexOf(search)>=0){
                clearInterval(interval);
                smsresponse = {found:true,error:false};
                resolve(smsresponse);
              }
            }

        },error=>{
          console.log(error);
          smsresponse={found:false,error:true};
          resolve(smsresponse);
        });
      },2000);
    });

  }
  updateUUID() {
   
     if(this.connectivityService.isOnline()){
      this.token=this.globalVars.createToken();
      let hashPass=this.globalVars.getHashPass(this.objectblock);

      this.body=JSON.stringify({
       esbRequest: {
          f0: "0200",
          f2: this.globalVars.getUsername(),
          f3: "120200",
          ESBUser: "chapchapplus",
          ESBWS: "http://192.168.60.233:7010/ESBWSConnector",
          ESBPassword: "chapchapplus",
          data:{
            37: this.token.field37,
            DEVICEID:this.device.uuid
          }  
        },
        mnoSession: {
          id: this.globalVars.getDate("9"),
          msisdn: this.globalVars.getUsername(),
          password:hashPass,
          deviceid: this.device.uuid
        }  
      });
        
      this.body=this.globalVars.getEncryptedVars(this.body);
     // console.log(this.body);
      
      let loader = this.loadingController.create({content:'Updating details'});
      loader.present();
      let body=this.body;
      let header= this.token;
     // console.log(header.hmac+"________"+header.token);
      this.apiConnect.load(body,header).then(data => {
        loader.dismiss();
        this.data=data;
        if(this.data.error==""){
          
          let response=this.globalVars.getDecryptedVars(this.data.data);
          // console.log(response);
          if(response.field39=="00"){
            let encrypted = this.globalVars.doAESencrypt(this.userNumber, this.device.uuid+"blablahblah");
            this.storage.set('xyz', encrypted);
            this.submit(this.objectblock); 
          }
          else{
            let template="<div>Failed to update details<br> Kindly try again</div>";
            let obj={body:this.body, template:template, completed:true, pageTo:''};
            let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
            myModal.present();
          }
        }
        else{
          let template="<div>"+this.data.error+"</div>";
          let obj={body:this.body, template:template, completed:true, pageTo:''};
          let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
          myModal.present();
        }
        
      });   
          
    }
    else{
      this.toast.show("Please connect to the Internet", '8000', 'bottom').subscribe(
        toast => {
        //console.log(toast);
      });
    }
  }
  shareSheetShare() {
    if(this.device.platform=="Android"){
        this.platform.ready().then(() => { 
        this.socialSharing.share("Check out the latest version of the NMB Mobile Banking App on the Google Play Store", "NMB Mobile", "", "").then(() => {
          //console.log("shareSheetShare: Success");
         
        }).catch(() => {
          //console.error("shareSheetShare: failed");
          let template="<div>Sorry message not sent</div>";
          let obj={body:"", template:template, completed:true, pageTo:''};
          let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
          myModal.present();
        });
      });
    }
    else{
        this.platform.ready().then(() => { 
          this.socialSharing.share("Check out the latest version of the NMB Mobile Banking App on the App Store", "NMB Mobile", "", "").then(() => {
            //console.log("shareSheetShare: Success");
            
          }).catch(() => {
            //console.error("shareSheetShare: failed");
            let template="<div>Sorry message not sent</div>";
            let obj={body:"", template:template, completed:true, pageTo:''};
            let myModal = this.modalCtrl.create('ConfirmModalPage',obj);
            myModal.present();
          });
      });
    }
  }

}
